import s from "./EditBlock.module.css";

const Barrier = () => {
  return (
    <div className={s.barrier}></div>
  );
};

export default Barrier;
