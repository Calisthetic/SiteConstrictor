import s from "./EditBlock.module.css";

const StyleCodes = () => {
  return (
    <div className={s.box_background}>
        <div className={s.box}></div>
    </div>
  );
};

export default StyleCodes;
